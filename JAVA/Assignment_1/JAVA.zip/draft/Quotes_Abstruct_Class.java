import java.util.*;

abstract public class Quotes_Abstruct_Class {
	
	ArrayList<String> Quotes = new ArrayList<String>();
	ArrayList<Integer> Time = new ArrayList<Integer>();
	
	abstract public void Initialize_Quotes_And_Time();

}
